document.addEventListener('DOMContentLoaded', () => {
    /*==================== SHOW MENU ====================*/
    const showMenu = (toggleId, navId) => {
        const toggle = document.getElementById(toggleId),
            nav = document.getElementById(navId);

        if (toggle && nav) {
            toggle.addEventListener('click', () => {
                nav.classList.toggle('show-menu');
            });
        }
    };
    showMenu('nav-toggle', 'nav-menu');

    /*==================== REMOVE MENU MOBILE ====================*/
    const navLink = document.querySelectorAll('.nav__link');

    function linkAction() {
        const navMenu = document.getElementById('nav-menu');
        if (navMenu) {
            navMenu.classList.remove('show-menu');
        }
    }
    navLink.forEach(n => n.addEventListener('click', linkAction));

    /*==================== SCROLL SECTIONS ACTIVE LINK ====================*/
    const sections = document.querySelectorAll('section[id]');

    function scrollActive() {
        const scrollY = window.pageYOffset;
    
        sections.forEach(current => {
            const sectionHeight = current.offsetHeight;
            const sectionTop = current.offsetTop - 50; // Adjust this value if needed
            const sectionId = current.getAttribute('id');
    
            const activeLink = document.querySelector('.nav__menu a[href*=' + sectionId + ']');
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                if (activeLink) {
                    activeLink.classList.add('active-link');
                }
            } else {
                if (activeLink) {
                    activeLink.classList.remove('active-link');
                }
            }
        });
    
        // Additional check to remove active class if at the bottom of the page
        if (scrollY + window.innerHeight >= document.body.offsetHeight) {
            const activeLink = document.querySelector('.nav__link.active-link');
            if (activeLink) {
                activeLink.classList.remove('active-link');
            }
        }
    }

    /*==================== SET ACTIVE LINK ====================*/
    const navLinks = document.querySelectorAll('.nav__link');
    const currentUrl = window.location.href;

    navLinks.forEach(link => {
        if (link.href === currentUrl) {
            link.classList.add('active-link');
        } else {
            link.classList.remove('active-link');
        }
    });

    /*==================== CHANGE BACKGROUND HEADER ====================*/
    function scrollHeader() {
        const nav = document.getElementById('header');
        if (nav) {
            if (this.scrollY >= 200) nav.classList.add('scroll-header');
            else nav.classList.remove('scroll-header');
        }
    }
    window.addEventListener('scroll', scrollHeader);

    /*==================== SHOW SCROLL TOP ====================*/
    function scrollTop() {
        const scrollTop = document.getElementById('scroll-top');
        if (scrollTop) {
            if (this.scrollY >= 560) scrollTop.classList.add('show-scroll');
            else scrollTop.classList.remove('show-scroll');
        }
    }
    window.addEventListener('scroll', scrollTop);

    /*==================== SCROLL REVEAL ANIMATION ====================*/
    const sr = ScrollReveal({
        origin: 'top',
        distance: '30px',
        duration: 2000,
        reset: true
    });

    sr.reveal(`.home__data, .home__img,
                .about__data, .about__img,
                .services__content, .menu__content,
                .contact__data, .contact__button .footer__content`, {
        interval: 200
    });
});